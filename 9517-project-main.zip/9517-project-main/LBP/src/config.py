radius = 3
n_points = 8 * radius
METHOD = 'uniform'
